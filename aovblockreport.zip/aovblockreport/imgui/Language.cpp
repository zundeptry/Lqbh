#include "Language.h"

std::map<LocalizedStringKey, std::string> localizedStrings;

Language currentLanguage;

void LoadLanguage(Language language) {
    localizedStrings.clear();

    switch (language) {
        case Language::Vietnamese:
            localizedStrings[LocalizedStringKey::UnlockSkin] = "Mở khóa Skin";
            localizedStrings[LocalizedStringKey::LanguageSetting] = "Language Setting";
            localizedStrings[LocalizedStringKey::SelectLanguage] = "Chọn Ngôn ngữ";
            localizedStrings[LocalizedStringKey::Vietnamese] = "Tiếng Việt";
            localizedStrings[LocalizedStringKey::English] = "English";
            localizedStrings[LocalizedStringKey::Taiwanese] = "台灣";
            localizedStrings[LocalizedStringKey::MainHack] = "Hack Chính";
            localizedStrings[LocalizedStringKey::AntiBan] = "AntiBan";
            localizedStrings[LocalizedStringKey::Info] = "Thông tin";
            localizedStrings[LocalizedStringKey::Hackmap] = "Hack Map";
            localizedStrings[LocalizedStringKey::LockCamera] = "Khóa Camera";
            localizedStrings[LocalizedStringKey::StartAIM] = "Bắt đầu AIM";
            localizedStrings[LocalizedStringKey::AimFeature] = "Tính năng AIM";
            localizedStrings[LocalizedStringKey::CustomizeYourView] = "Tùy chỉnh Góc nhìn";
            localizedStrings[LocalizedStringKey::ShowCD] = "Hiển thị CD";
            localizedStrings[LocalizedStringKey::SaveSetting] = "Lưu Cài đặt";
            localizedStrings[LocalizedStringKey::UseSetting] = "Sử dụng Cài đặt";
            localizedStrings[LocalizedStringKey::ResetSetting] = "Đặt lại Cài đặt";
            localizedStrings[LocalizedStringKey::AimTrigger] = "Kích hoạt Aim";
            localizedStrings[LocalizedStringKey::DrawAimedObject] = "Vẽ đối tượng được nhắm";
            localizedStrings[LocalizedStringKey::LowestHealthPercent] = "Tỉ lệ máu thấp nhất";
            localizedStrings[LocalizedStringKey::LowestHealth] = "Máu thấp nhất";
            localizedStrings[LocalizedStringKey::NearestDistance] = "Khoảng cách gần nhất";
            localizedStrings[LocalizedStringKey::ClosestToRay] = "Gần tia nhất";
            localizedStrings[LocalizedStringKey::No] = "Không";
            localizedStrings[LocalizedStringKey::Always] = "Luôn luôn";
            localizedStrings[LocalizedStringKey::WhenWatching] = "Khi đang aim";
            localizedStrings[LocalizedStringKey::Contact] = "Liên hệ";
            localizedStrings[LocalizedStringKey::Telegram] = "Telegram: @tuananh.dll";
            localizedStrings[LocalizedStringKey::Admin] = "ADMIN: @tuananh.dll";
            localizedStrings[LocalizedStringKey::HackInformation] = "Thông tin Hack";
            localizedStrings[LocalizedStringKey::HackName] = "Tên Hack: AOV VIP PRO";
            localizedStrings[LocalizedStringKey::Version] = "Phiên bản: 99.99+";
            localizedStrings[LocalizedStringKey::Features] = "Chức Năng: ESP, Aimbot, Unlock Skin";
            localizedStrings[LocalizedStringKey::Advertisement] = "Quảng cáo";
            localizedStrings[LocalizedStringKey::BuyServerKey] = "Mua Project Liên Hệ Admin";
            break;
        case Language::English:
            localizedStrings[LocalizedStringKey::UnlockSkin] = "Unlock Skin";
            localizedStrings[LocalizedStringKey::LanguageSetting] = "Language Setting";
            localizedStrings[LocalizedStringKey::SelectLanguage] = "Select Language";
            localizedStrings[LocalizedStringKey::Vietnamese] = "Tiếng Việt";
            localizedStrings[LocalizedStringKey::English] = "English";
            localizedStrings[LocalizedStringKey::Taiwanese] = "台灣";
            localizedStrings[LocalizedStringKey::MainHack] = "Main Hack";
            localizedStrings[LocalizedStringKey::AntiBan] = "AntiBan";
            localizedStrings[LocalizedStringKey::Info] = "Info";
            localizedStrings[LocalizedStringKey::Hackmap] = "Hack Map";
            localizedStrings[LocalizedStringKey::LockCamera] = "Lock Camera";
            localizedStrings[LocalizedStringKey::StartAIM] = "Start AIM";
            localizedStrings[LocalizedStringKey::AimFeature] = "AIM Feature";
            localizedStrings[LocalizedStringKey::CustomizeYourView] = "Customize View";
            localizedStrings[LocalizedStringKey::ShowCD] = "Show CD";
            localizedStrings[LocalizedStringKey::SaveSetting] = "Save Setting";
            localizedStrings[LocalizedStringKey::UseSetting] = "Use Setting";
            localizedStrings[LocalizedStringKey::ResetSetting] = "Reset Setting";
            localizedStrings[LocalizedStringKey::AimTrigger] = "Aim Trigger";
            localizedStrings[LocalizedStringKey::DrawAimedObject] = "Draw Aimed Object";
            localizedStrings[LocalizedStringKey::LowestHealthPercent] = "Lowest Health %";
            localizedStrings[LocalizedStringKey::LowestHealth] = "Lowest Health";
            localizedStrings[LocalizedStringKey::NearestDistance] = "Nearest Distance";
            localizedStrings[LocalizedStringKey::ClosestToRay] = "Closest to Ray";
            localizedStrings[LocalizedStringKey::No] = "No";
            localizedStrings[LocalizedStringKey::Always] = "Always";
            localizedStrings[LocalizedStringKey::WhenWatching] = "When Watching";
            localizedStrings[LocalizedStringKey::Contact] = "Contact";
            localizedStrings[LocalizedStringKey::Telegram] = "Telegram: @tuananh.dll";
            localizedStrings[LocalizedStringKey::Admin] = "ADMIN: @tuananh.dll";
            localizedStrings[LocalizedStringKey::HackInformation] = "Hack Info";
            localizedStrings[LocalizedStringKey::HackName] = "Hack Name: AOV VIP PRO";
            localizedStrings[LocalizedStringKey::Version] = "Version: 99.99+";
            localizedStrings[LocalizedStringKey::Features] = "Features: ESP, Aimbot, Unlock Skin";
            localizedStrings[LocalizedStringKey::Advertisement] = "Advertisement";
            localizedStrings[LocalizedStringKey::BuyServerKey] = "Buy Project Contact Admin";
            break;
        case Language::Taiwanese:
            localizedStrings[LocalizedStringKey::UnlockSkin] = "解鎖皮膚";
            localizedStrings[LocalizedStringKey::LanguageSetting] = "語言設定";
            localizedStrings[LocalizedStringKey::SelectLanguage] = "選擇語言";
            localizedStrings[LocalizedStringKey::Vietnamese] = "Tiếng Việt";
            localizedStrings[LocalizedStringKey::English] = "English";
            localizedStrings[LocalizedStringKey::Taiwanese] = "台灣";
            localizedStrings[LocalizedStringKey::MainHack] = "主要駭客";
            localizedStrings[LocalizedStringKey::AntiBan] = "皮膚";
            localizedStrings[LocalizedStringKey::Info] = "資訊";
            localizedStrings[LocalizedStringKey::Hackmap] = "駭客地圖";
            localizedStrings[LocalizedStringKey::LockCamera] = "鎖定相機";
            localizedStrings[LocalizedStringKey::StartAIM] = "開始瞄準";
            localizedStrings[LocalizedStringKey::AimFeature] = "瞄準功能";
            localizedStrings[LocalizedStringKey::CustomizeYourView] = "自定義視圖";
            localizedStrings[LocalizedStringKey::ShowCD] = "顯示CD";
            localizedStrings[LocalizedStringKey::SaveSetting] = "儲存設定";
            localizedStrings[LocalizedStringKey::UseSetting] = "使用設定";
            localizedStrings[LocalizedStringKey::ResetSetting] = "重設設定";
            localizedStrings[LocalizedStringKey::AimTrigger] = "瞄準觸發器";
            localizedStrings[LocalizedStringKey::DrawAimedObject] = "繪製瞄準對象";
            localizedStrings[LocalizedStringKey::LowestHealthPercent] = "最低生命值百分比";
            localizedStrings[LocalizedStringKey::LowestHealth] = "最低生命值";
            localizedStrings[LocalizedStringKey::NearestDistance] = "最近距離";
            localizedStrings[LocalizedStringKey::ClosestToRay] = "最靠近光線";
            localizedStrings[LocalizedStringKey::No] = "否";
            localizedStrings[LocalizedStringKey::Always] = "總是";
            localizedStrings[LocalizedStringKey::WhenWatching] = "觀看時";
            localizedStrings[LocalizedStringKey::Contact] = "聯繫方式";
            localizedStrings[LocalizedStringKey::Telegram] = "Telegram: @tuananh.dll";
            localizedStrings[LocalizedStringKey::Admin] = "管理員: @tuananh.dll";
            localizedStrings[LocalizedStringKey::HackInformation] = "駭客資訊";
            localizedStrings[LocalizedStringKey::HackName] = "駭客名稱: ESP Aov";
            localizedStrings[LocalizedStringKey::Version] = "版本: 99.99+";
            localizedStrings[LocalizedStringKey::Features] = "功能: ESP, Aimbot, Modskin";
            localizedStrings[LocalizedStringKey::Advertisement] = "廣告";
            localizedStrings[LocalizedStringKey::BuyServerKey] = "購買ServerKey請聯繫管理員";
            break;
    }
}