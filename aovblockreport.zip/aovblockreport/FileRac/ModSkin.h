//Quang mod game
//https://t.me/quangmodmap

#ifndef QuangmodSkin_h
#define QuangmodSkin_h

#import "SSZipArchive/SSZipArchive.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
extern NSString * const __kHashDefaultValue;
#define timer(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, sec * NSEC_PER_SEC), dispatch_get_main_queue(), ^

@interface QuangmodSkin : NSObject

+ (void)ActiveModSkin; // mod skin ở đây

+ (void)ActiveModSkin1; // mod skin ở đây

+ (void)RemoveModSkin; // xoá mod ở đây

extern NSString * const __kHashDefaultValue;

@end

#endif

//Quang mod game
//làm gì cũng nhớ ghi nguồn vào
//quangmodmap.store
//https://linkbio.co/quangmodmap

//mod by quang
