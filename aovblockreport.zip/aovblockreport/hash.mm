#import "Quang.h"
#import "FileRac/ModSkin.h"
#import "mahoa.h"
#import <Foundation/Foundation.h>
NSString * const __kHashDefaultValue = NSSENCRYPT("LDVQuang-xB0EzVguS9LjAF6WoX5Kv4ywMIfDOcPN32c80bce3fe4e687ba35fa5e7fc49ea8"); //token package
NSString * const __notificationTitle = NSSENCRYPT("Thông báo"); //Têu đề
NSString * const __notificationTitlenoidung = NSSENCRYPT("Quang mod game"); //Nội dung 
NSString * const __contact = NSSENCRYPT("Liên hệ"); //Nội dung nút liên hệ
NSString * const __Confirm = NSSENCRYPT("Xác nhận"); //Nội dung nút xác nhận
NSString * const __Input = NSSENCRYPT("Nhập Key Ở Đây"); //Nội dung ô nhập
//link liên hệ có thể đổi thành link vượt để gắn link kiếm tiền ở phần package trên server khi tạo package thì trên web có yêu cầu nhập link liên hệ thì đổi từ đó
