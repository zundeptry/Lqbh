#ifndef VariableObfuscation_h

#define VariableObfuscation_h
//confuse string at Sat Jun  1 12:22:49 +07 2024
#define open RFUXSLQQXSDSSLAC
#define GetImGuiView CILVRLFGDLGFQBDO
#define extraInfo YLZORSBXYIPWTHHS
#define InvisibleMenuButton ZPAFKWSVRDV
#define VisibleMenuButton EYDQETRJFBIVTHHK
#define hideRecordTextfield TMLAQPKYYYYUNKOY
#define hideRecordView HMKUMEUTUFUTZPBS
// #define API UQPKJWZXTXQDWDUC
#endif
